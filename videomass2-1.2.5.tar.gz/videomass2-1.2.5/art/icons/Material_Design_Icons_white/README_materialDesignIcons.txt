Link:
https://iconpharm.com/license/
http://google.github.io/material-design-icons/
https://github.com/google/material-design-icons
