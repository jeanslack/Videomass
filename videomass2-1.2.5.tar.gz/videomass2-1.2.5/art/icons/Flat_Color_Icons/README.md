# Icons8 Flat Color Icons

**For High-Class Bitches**

You must be spoiled by expensive gifts and won't be impressed. Stop reading.

**For the Rest of Us**

Now that we are alone, let us give you something: 312 free icons for personal and commercial use. No credits required.

But hey, don't get spoiled too quickly. Next time, when we present you with a Tiffany ring, at least pretend you're impressed!

[![Preview of Flat Icons from Icons8](https://cdnd.icons8.com/download/images/flat-color-icons.png)](https://icons8.github.io/flat-color-icons/)

There is available a live [preview](https://icons8.github.io/flat-color-icons/) of the icon set.

##Good Boy License
We’ve released the icon pack either under MIT or the [Good Boy License](https://icons8.com/good-boy-license/). We invented it. Please do _whatever your mom would approve of:_
* Download
* Change
* Fork

No tattoos!

## More Color Icons

These 317 icons are the part of a bigger pack available for a fee: https://icons8.com/color-icons (4500 icons as of February 2017).

## Author

* [Home Page](https://icons8.com/color-icons)
* [Project Blog](https://icons8.com/blog)
* [Twitter](https://twitter.com/icons_8)
* [Facebook Page](https://www.facebook.com/Icons8)
* [Dribbble](https://dribbble.com/icons8)

## Installing Icons8 flat color icons

You can install this package locally either with `npm`, `bower`, or `jspm`.

### npm

```shell
npm install flat-color-icons
```

### bower

```shell
bower install flat-color-icons
```

## Questions or Ideas?

If you have any questions or ideas about icons, please feel free to contact us any way you'd prefer
* create an [issue](https://github.com/icons8/flat-color-icons/issues) on github
* tweet us [@Icons_8](https://twitter.com/icons_8)
* drop a comment on [icons8.com](https://icons8.com/c).
